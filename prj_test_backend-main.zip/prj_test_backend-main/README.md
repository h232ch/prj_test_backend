# install
pip install -r requirements.txt

# run
python manage.py runserver

# connect
http://localhost:8000/
